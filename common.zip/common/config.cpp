//
// Created by lining on 2023/4/23.
//

#include "config.h"

LocalConfig localConfig;